package sample;

import javafx.scene.Group;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Map;

import java.util.ArrayList;

public class CargaFlechas {

    public Group cargaFlechas(Stage primaryStage, Map map, int cordXActual, int cordYActual, int numFlechas){

        Group groupFlechas = null;
        
        int indexSala=0;
        for (int i=0; i<map.getArrSalas().size() ; i++){
            if (map.getArrSalas().get(i).getCordX()==cordXActual && map.getArrSalas().get(i).getCordY()==cordYActual){
                indexSala = i;
            }
        }
        
        for (int i=0 ; i<numFlechas ; i++){
            groupFlechas = createFlechas(primaryStage, numFlechas, map, indexSala);
        }
        
        return groupFlechas;
    }

    private Group createFlechas(Stage primaryStage, int numFlechas, Map map, int indexSala){

        Group groupFlechas = null;
        ImageView btnFlecha;
        ArrayList<ImageView> arrFlechas = new ArrayList<>();
        char direccion;
        /*int cordXActual = map.getArrSalas().get(indexSala).getCordX();
        int cordYActual = map.getArrSalas().get(indexSala).getCordY();
        int indexNuevaSala = 0;*/
        for (int i=1 ; i<=numFlechas ; i++){

            direccion = map.getArrSalas().get(indexSala).getTipoFondo().charAt(i);
            btnFlecha = asignaFlechas(direccion, primaryStage, map, indexSala);
            btnFlecha.setFitWidth(60);
            btnFlecha.setFitHeight(50);
            btnFlecha.setVisible(true);
            btnFlecha.getStyleClass().add("btnNext");
            
            arrFlechas.add(btnFlecha);
        }


        switch (numFlechas){
            case 1:
                groupFlechas = new Group(arrFlechas.get(0));
                break;

            case 2:
                groupFlechas = new Group(arrFlechas.get(0), arrFlechas.get(1));
                break;

            case 3:
                groupFlechas = new Group(arrFlechas.get(0), arrFlechas.get(1), arrFlechas.get(2));
                break;

            case 4:
                groupFlechas = new Group(arrFlechas.get(0), arrFlechas.get(1), arrFlechas.get(2), arrFlechas.get(3));
                break;
        }
        
        
        return groupFlechas;
    }

    private ImageView asignaFlechas(char direccion, Stage primaryStage, Map map, int indexSala){

        ImageView flecha;
        int cordXActual = map.getArrSalas().get(indexSala).getCordX();
        int cordYActual = map.getArrSalas().get(indexSala).getCordY();
        int indexNuevaSala=0;

        if(direccion=='I'){

            flecha = new ImageView("imgs/icons/flechaAtras.png");
            flecha.setTranslateX(20);
            flecha.setTranslateY(300);
            for (int i=0; i<map.getArrSalas().size() ; i++){
                if (map.getArrSalas().get(i).getCordX()==(cordXActual-1) && map.getArrSalas().get(i).getCordY()==(cordYActual)){
                    indexNuevaSala = i;
                }
            }
            creaOnClick(primaryStage, flecha, map, indexNuevaSala);

        } else if (direccion=='A'){
            flecha = new ImageView("imgs/icons/flechaArriba.png");
            flecha.setTranslateX(350);
            flecha.setTranslateY(200);
            for (int i=0; i<map.getArrSalas().size() ; i++){
                if (map.getArrSalas().get(i).getCordX()==cordXActual && map.getArrSalas().get(i).getCordY()==(cordYActual+1)){
                    indexNuevaSala = i;
                }
            }
            creaOnClick(primaryStage, flecha, map, indexNuevaSala);

        }else if(direccion=='D'){
            flecha = new ImageView("imgs/icons/flechaDerecha.png");
            flecha.setTranslateX(575);
            flecha.setTranslateY(300);
            for (int i=0; i<map.getArrSalas().size() ; i++){
                if (map.getArrSalas().get(i).getCordX()==(cordXActual+1) && map.getArrSalas().get(i).getCordY()==(cordYActual)){
                    indexNuevaSala = i;
                }
            }
            creaOnClick(primaryStage, flecha, map, indexNuevaSala);

        }else{
            flecha = new ImageView("imgs/icons/flechaAbajo.png");
            flecha.setTranslateX(350);
            flecha.setTranslateY(450);
            for (int i=0; i<map.getArrSalas().size() ; i++){
                if (map.getArrSalas().get(i).getCordX()==cordXActual && map.getArrSalas().get(i).getCordY()==(cordYActual-1)){
                    indexNuevaSala = i;
                }
            }
            creaOnClick(primaryStage, flecha, map, indexNuevaSala);
        }
        return flecha;
    }

    private void creaOnClick(Stage primaryStage, ImageView flecha, Map map, int indexNuevaSala){
        //System.out.println("Tipo de sala: "+map.getArrSalas().get(indexNuevaSala).getTipoSala());
        switch (map.getArrSalas().get(indexNuevaSala).getTipoSala()){
            case 0:
                flecha.setOnMouseClicked(event -> {
                    SalasInicio salasInicio = new SalasInicio();
                    salasInicio.cargaSalaInicio(primaryStage, map, indexNuevaSala);
                });
                break;

            case 1:
                flecha.setOnMouseClicked(event -> {
                    SalasVacio salasVacio = new SalasVacio();
                    salasVacio.cargaSalasVacio(primaryStage, map, indexNuevaSala);
                });
                break;

            case 2:
                flecha.setOnMouseClicked(event -> {
                    SalasCombate salasCombate = new SalasCombate();
                    salasCombate.cargaSalaCombate(primaryStage, map, indexNuevaSala);
                });
                break;

            case 3:
                flecha.setOnMouseClicked(event -> {
                    SalasTesoro salasTesoro = new SalasTesoro();
                    salasTesoro.cargaSalaTesoro(primaryStage, map, indexNuevaSala);
                });
                break;

            case -3:
                flecha.setOnMouseClicked(event -> {
                    SalasTesoroVacia salasTesoroVacia = new SalasTesoroVacia();
                    salasTesoroVacia.cargaSalaTesoroVacia(primaryStage, map, indexNuevaSala);
                });
                break;

            case 4:
                flecha.setOnMouseClicked(event -> {
                    SalasBoss salasBoss = new SalasBoss();
                    salasBoss.cargaSalaBoss();
                });
                break;

            case 5:
                flecha.setOnMouseClicked(event -> {
                    SalasTienda salasTienda = new SalasTienda();
                    salasTienda.cargaSalasTienda();
                });
                break;

            case 6:
                flecha.setOnMouseClicked(event -> {
                    SalasCuracion salasCuracion = new SalasCuracion();
                    salasCuracion.cargaSalasCuracion(primaryStage, map, indexNuevaSala);
                });
                break;

            case -6:
                flecha.setOnMouseClicked(event -> {
                    SalasCuracionVacia salasCuracionVacia = new SalasCuracionVacia();
                    salasCuracionVacia.cargaSalasCuracionVacia(primaryStage, map, indexNuevaSala);
                });
                break;

            case 7:
                flecha.setOnMouseClicked(event -> {
                    SalasAcertijo salasAcertijo = new SalasAcertijo();
                    salasAcertijo.cargaSalasAcertijo();
                });
                break;
        }

    }
}
