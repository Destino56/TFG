package sample;

public class SalasBoss {

    public void cargaSalaBoss(){

    }
}
