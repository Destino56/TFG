package sample;

import javafx.application.Application;
import javafx.stage.Stage;
import model.Map;

import java.util.Random;

public class Inicio extends Application {

    @Override
    public void start(Stage primaryStage){

        primaryStage.setMinHeight(711);
        primaryStage.setMinWidth(670);
        primaryStage.setMaxWidth(670);
        primaryStage.setMaxHeight(711);
        primaryStage.setTitle("Piso - 1");

        Random r = new Random();
        int mapaSeleccionado;
        String nombreMapa;
        nombreMapa = "forest/fondoBosque";
        /*mapaSeleccionado = r.nextInt((2)) + 1;
        if (mapaSeleccionado==1){
            nombreMapa = "forest/fondoBosque";
        }else{
            nombreMapa = "desert/desierto";
        }*/

        //mapaSeleccionado = r.nextInt((8)) + 1;
        mapaSeleccionado = 1;
        LoadData loadData = new LoadData();
        loadData.restartStatsCharacter();
        Map map = loadData.cargaInfoMapa(mapaSeleccionado, nombreMapa);

        SalasInicio salasInicio = new SalasInicio();
        salasInicio.cargaSalaInicio(primaryStage, map, 0);
    }


    public static void main(String[] args) { launch(args); }
}
