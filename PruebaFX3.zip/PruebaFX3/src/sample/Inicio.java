package sample;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import model.Map;

import java.util.Random;

public class Inicio extends Application {

    @Override
    public void start(Stage primaryStage){

        primaryStage.setMinHeight(711);
        primaryStage.setMinWidth(670);
        primaryStage.setMaxWidth(670);
        primaryStage.setMaxHeight(711);

        LoadData loadData = new LoadData();
        Group characters = loadData.cargaCharacter(60, 100);

        Label titulo = new Label("T-F-G");
        titulo.setStyle("-fx-font-size: 50px; -fx-font-family: ");
        titulo.setTranslateX(200);
        titulo.setTranslateY(30);

        Rectangle rectangle = new Rectangle(670, 711);
        rectangle.setFill(Color.WHITE);
        Button btnEmpezar = new Button("Comenzar aventura");
        btnEmpezar.setTranslateX(200);
        btnEmpezar.setTranslateY(400);
        btnEmpezar.setMinWidth(100);
        btnEmpezar.setMinHeight(50);
        btnEmpezar.setStyle("-fx-font-size: 25px");
        btnEmpezar.setOnAction(event -> {

            Random r = new Random();
            int mapaSeleccionado;
            String nombreMapa;
            //nombreMapa = "tundra/tundra";
            mapaSeleccionado = r.nextInt((2)) + 1;
            if (mapaSeleccionado==1){
                nombreMapa = "forest/fondoBosque";
            }else{
                nombreMapa = "desert/desierto";
            }

            mapaSeleccionado = r.nextInt((8)) + 1;
            //mapaSeleccionado = 1;
            loadData.restartStatsCharacter();
            Map map = loadData.cargaInfoMapa(mapaSeleccionado, nombreMapa);

            SalasInicio salasInicio = new SalasInicio();
            salasInicio.cargaSalaInicio(primaryStage, map, 0);
        });
        Group root = new Group(rectangle, btnEmpezar, characters, titulo);
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }


    public static void main(String[] args) { launch(args); }
}
