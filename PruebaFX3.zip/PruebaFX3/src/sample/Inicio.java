package sample;

import javafx.application.Application;
import javafx.stage.Stage;
import model.Map;

import java.util.Random;

public class Inicio extends Application {

    @Override
    public void start(Stage primaryStage){

        primaryStage.setMinHeight(711);
        primaryStage.setMinWidth(670);
        primaryStage.setMaxWidth(670);
        primaryStage.setMaxHeight(711);
        primaryStage.setTitle("Piso - 1");

        Random r = new Random();
        int mapaSeleccionado = r.nextInt((8)) + 1;

        LoadData loadData = new LoadData();
        System.out.println("Ha tocado el mapa número "+mapaSeleccionado);
        Map map = loadData.cargaInfoMapa(mapaSeleccionado);

        SalasInicio salasInicio = new SalasInicio();
        salasInicio.cargaSalaInicio(primaryStage, map, 0);
    }


    public static void main(String[] args) { launch(args); }
}
