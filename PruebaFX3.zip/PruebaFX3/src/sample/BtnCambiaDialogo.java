package sample;

import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class BtnCambiaDialogo {

    public void cambiaDialogo(Label dialogo, String texto){
        dialogo.setText(texto);
    }

    public void boton(Button btnDialogo, Label dialogo, String texto){
        btnDialogo.setOnAction(event -> {
            dialogo.setText(texto);
        });
    }
}
