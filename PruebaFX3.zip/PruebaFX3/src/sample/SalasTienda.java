package sample;

public class SalasTienda {

    public void cargaSalasTienda(){

    }
}
