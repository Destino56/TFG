package sample;

public class SalasMercader {

    public void cargaSalasMercader(){

    }
}
