package sample;

import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Entity;
import model.Map;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Random;

public class SalasCombate {

    private Group characters;
    private Group enemies;
    private ImageView character, enemie;

    public void cargaSalaCombate(Stage primaryStage, int cordXActual, int cordYActual) {

        ArrayList<Entity> arrEntitys = loadEntitys();

        ArrayList<ImageView> arrCharacter = new ArrayList<>();
        ArrayList<ImageView> arrEnemies = new ArrayList<>();

        String ruta;
        for (int i = 1; i <= 10; i++) {
            ruta = "imgs/" + arrEntitys.get(0).getFolder() +
                    "/" + arrEntitys.get(0).getSprite() + i + ".png";
            character = new ImageView(ruta);
            arrCharacter.add(character);
        }

        Random r = new Random();
        int monstruoSeleccionado = r.nextInt((arrEntitys.size() - 1)) + 1;
        for (int i = 1; i <= arrEntitys.get(monstruoSeleccionado).getNumSprites(); i++) {

            ruta = "imgs/enemies/" + arrEntitys.get(monstruoSeleccionado).getFolder() +
                    "/" + arrEntitys.get(monstruoSeleccionado).getSprite() + i + ".png";
            enemie = new ImageView(ruta);
            enemie.setFitWidth(arrEntitys.get(monstruoSeleccionado).getWidht());
            enemie.setFitHeight(arrEntitys.get(monstruoSeleccionado).getHeight());
            arrEnemies.add(enemie);
        }

        characters = new Group(arrCharacter.get(0));
        enemies = new Group(arrEnemies.get(0));

        characters.setTranslateX(50);
        characters.setTranslateY(245);
        enemies.setTranslateX(arrEntitys.get(monstruoSeleccionado).getPosX());
        enemies.setTranslateY(arrEntitys.get(monstruoSeleccionado).getPosY());

        Timeline timelineCharacter = new Timeline();
        timelineCharacter.setCycleCount(Timeline.INDEFINITE);
        Timeline timelineEnemies = new Timeline();
        timelineEnemies.setCycleCount(Timeline.INDEFINITE);

        new Animaciones().animacion(arrCharacter, timelineCharacter, characters, arrCharacter.size());
        timelineCharacter.play();
        new Animaciones().animacion(arrEnemies, timelineEnemies, enemies, arrEnemies.size());
        timelineEnemies.play();

        ProgressBar characterHealth = new ProgressBar(1);
        characterHealth.setStyle("-fx-accent: green");
        characterHealth.setTranslateX(arrEntitys.get(0).getPosXVida());
        characterHealth.setTranslateY(arrEntitys.get(0).getPosYVida());

        ProgressBar enemieHealth = new ProgressBar(1);
        enemieHealth.setStyle("-fx-accent: red");
        enemieHealth.setTranslateX(arrEntitys.get(monstruoSeleccionado).getPosXVida());
        enemieHealth.setTranslateY(arrEntitys.get(monstruoSeleccionado).getPosYVida());

        Label dialogo = new Label();
        dialogo.setTranslateX(25);
        dialogo.setTranslateY(525);
        dialogo.setMinWidth(600);
        dialogo.setMaxWidth(600);
        dialogo.setMinHeight(100);
        dialogo.setMaxHeight(100);
        dialogo.setStyle("-fx-background-color: #f7f1f0; -fx-padding: 20px; -fx-font-size: 15px");

        LoadData loadData = new LoadData();
        Map map = loadData.cargaInfoMapa();

        int indexSala=0;
        for (int i=0; i<map.getArrSalas().size() ; i++){
            if (map.getArrSalas().get(i).getCordX()==cordXActual && map.getArrSalas().get(i).getCordY()==cordYActual){
                indexSala = i;
            }
        }
        int numFlechas = Character.getNumericValue(map.getArrSalas().get(indexSala).getTipoFondo().charAt(0));

        ImageView background = new ImageView("imgs/background/"+map.getNombrePiso()+map.getArrSalas().get(indexSala).getTipoFondo()+".png");
        background.setFitHeight(511);
        background.setFitWidth(670);
        CargaFlechas cargaFlechas = new CargaFlechas();
        Group flechas = cargaFlechas.cargaFlechas(primaryStage, map, 0, 0, numFlechas);

        Group root = new Group(background, characters, enemies, dialogo, flechas, characterHealth, enemieHealth);
        Scene scene = new Scene(root);
        scene.getStylesheets().add("styles/styles.css");
        primaryStage.setScene(scene);
        primaryStage.show();

    }


    public ArrayList<Entity> loadEntitys(){

        BufferedReader bufferedReader;
        ArrayList<Entity> arrEntitys = new ArrayList<>();

        try {

            bufferedReader = new BufferedReader(new FileReader("files/stats.txt"));
            String line="";
            while ((line=bufferedReader.readLine())!=null) {
                String[] fields = line.split(";");
                Entity entity = new Entity();
                entity.setId(Integer.parseInt(fields[0]));
                entity.setName(fields[1]);
                entity.setHealth(Integer.parseInt(fields[2]));
                entity.setDice(Integer.parseInt(fields[3]));
                entity.setDamage(Integer.parseInt(fields[4]));
                entity.setDodge(Integer.parseInt(fields[5]));
                entity.setPrecission(Integer.parseInt(fields[6]));
                entity.setFolder(fields[7]);
                entity.setSprite(fields[8]);
                entity.setWidht(Integer.parseInt(fields[9]));
                entity.setHeight(Integer.parseInt(fields[10]));
                entity.setPosX(Integer.parseInt(fields[11]));
                entity.setPosY(Integer.parseInt(fields[12]));
                entity.setPosXVida(Integer.parseInt(fields[13]));
                entity.setPosYVida(Integer.parseInt(fields[14]));
                entity.setNumSprites(Integer.parseInt(fields[15]));
                arrEntitys.add(entity);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrEntitys;
    }
}
