package sample;

import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Entity;
import model.Map;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Random;

public class SalasCombate {

    private Group enemies;
    private ImageView enemie;
    private ArrayList<Entity> arrEntitys = new ArrayList<>();

    public void cargaSalaCombate(Stage primaryStage, Map map, int indexNuevaSala) {

        arrEntitys = loadEntitys();

        int cordXActual = map.getArrSalas().get(indexNuevaSala).getCordX();
        int cordYActual = map.getArrSalas().get(indexNuevaSala).getCordY();

        ArrayList<ImageView> arrEnemies = new ArrayList<>();

        String ruta;
        Random r = new Random();
        int monstruoSeleccionado;
        if (map.getNombrePiso() == "forest/fondoBosque"){
            monstruoSeleccionado = r.nextInt(5) + 1;
        }else{
            monstruoSeleccionado = r.nextInt(5) + 7;
        }

        for (int i = 1; i <= arrEntitys.get(monstruoSeleccionado).getNumSprites(); i++) {
            ruta = "imgs/enemies/" + arrEntitys.get(monstruoSeleccionado).getFolder() +
                    "/" + arrEntitys.get(monstruoSeleccionado).getSprite() + i + ".png";
            enemie = new ImageView(ruta);
            enemie.setFitWidth(arrEntitys.get(monstruoSeleccionado).getWidht());
            enemie.setFitHeight(arrEntitys.get(monstruoSeleccionado).getHeight());
            arrEnemies.add(enemie);
        }

        enemies = new Group(arrEnemies.get(0));

        enemies.setTranslateX(arrEntitys.get(monstruoSeleccionado).getPosX());
        enemies.setTranslateY(arrEntitys.get(monstruoSeleccionado).getPosY());

        Timeline timelineCharacter = new Timeline();
        timelineCharacter.setCycleCount(Timeline.INDEFINITE);
        Timeline timelineEnemies = new Timeline();
        timelineEnemies.setCycleCount(Timeline.INDEFINITE);

        new Animaciones().animacion(arrEnemies, timelineEnemies, enemies, arrEnemies.size());
        timelineEnemies.play();

        ProgressBar characterHealth = new ProgressBar(1);
        characterHealth.setStyle("-fx-accent: green");
        characterHealth.setTranslateX(arrEntitys.get(0).getPosXVida());
        characterHealth.setTranslateY(arrEntitys.get(0).getPosYVida());

        ProgressBar enemieHealth = new ProgressBar(1);
        enemieHealth.setStyle("-fx-accent: red");
        enemieHealth.setTranslateX(arrEntitys.get(monstruoSeleccionado).getPosXVida());
        enemieHealth.setTranslateY(arrEntitys.get(monstruoSeleccionado).getPosYVida());

        ImageView background = new ImageView("imgs/background/"+map.getNombrePiso()+map.getArrSalas().get(indexNuevaSala).getTipoFondo()+".png");
        background.setFitHeight(511);
        background.setFitWidth(670);

        int numFlechas = Character.getNumericValue(map.getArrSalas().get(indexNuevaSala).getTipoFondo().charAt(0));
        CargaFlechas cargaFlechas = new CargaFlechas();
        Group flechas = cargaFlechas.cargaFlechas(primaryStage, map, cordXActual, cordYActual, numFlechas);

        LoadData loadData = new LoadData();
        Group characters = loadData.cargaCharacter(-40, 175);
        Label dialogo = loadData.cargaLabel();

        Button btnAtacar = new Button("Atacar");
        btnAtacar.setTranslateX(300);
        btnAtacar.setTranslateY(640);
        btnAtacar.setOnAction(event -> {

            int valueVidaEnemigo = atacar(enemieHealth, 0, arrEntitys.get(monstruoSeleccionado).getId(), enemies);
            if (valueVidaEnemigo<=0){
                dialogo.setText("Has acabado con el enemigo: "+arrEntitys.get(monstruoSeleccionado).getName());
                btnAtacar.setVisible(false);
                flechas.setVisible(true);
                map.getArrSalas().get(indexNuevaSala).setTipoSala(1);
                loadData.updateStatsCharacter(2, String.valueOf(arrEntitys.get(0).getHealth()));
            }else{
                int vidaJugador = atacar(characterHealth, arrEntitys.get(monstruoSeleccionado).getId(), 0, characters);
                if (vidaJugador<=0){
                    dialogo.setText("Has sido asesinado a manos de el enemigo: "+arrEntitys.get(monstruoSeleccionado).getName());
                    btnAtacar.setVisible(false);
                }
            }
        });
        flechas.setVisible(false);
        Group root = new Group(background, characters, enemies, dialogo, flechas, characterHealth, enemieHealth, btnAtacar);
        Scene scene = new Scene(root);
        scene.getStylesheets().add("styles/styles.css");
        primaryStage.setScene(scene);
        primaryStage.show();

    }


    public ArrayList<Entity> loadEntitys(){

        BufferedReader bufferedReader;
        ArrayList<Entity> arrEntitys = new ArrayList<>();

        try {

            bufferedReader = new BufferedReader(new FileReader("files/stats.txt"));
            String line="";
            while ((line=bufferedReader.readLine())!=null) {
                String[] fields = line.split(";");
                Entity entity = new Entity();
                entity.setId(Integer.parseInt(fields[0]));
                entity.setName(fields[1]);
                entity.setHealth(Integer.parseInt(fields[2]));
                entity.setDice(Integer.parseInt(fields[3]));
                entity.setDamage(Integer.parseInt(fields[4]));
                entity.setDodge(Integer.parseInt(fields[5]));
                entity.setPrecission(Integer.parseInt(fields[6]));
                entity.setFolder(fields[7]);
                entity.setSprite(fields[8]);
                entity.setWidht(Integer.parseInt(fields[9]));
                entity.setHeight(Integer.parseInt(fields[10]));
                entity.setPosX(Integer.parseInt(fields[11]));
                entity.setPosY(Integer.parseInt(fields[12]));
                entity.setPosXVida(Integer.parseInt(fields[13]));
                entity.setPosYVida(Integer.parseInt(fields[14]));
                entity.setNumSprites(Integer.parseInt(fields[15]));
                arrEntitys.add(entity);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        LoadData loadData = new LoadData();
        arrEntitys = loadData.loadStatsCharacter(arrEntitys);

        System.out.println(arrEntitys.get(0).getName());

        return arrEntitys;
    }

    public int atacar(ProgressBar barraVida, int atacante, int enemigo, Group enemigoG){
        Entity entity = arrEntitys.get(enemigo);
        Random r = new Random();
        int acierto = r.nextInt(20)+1;
        System.out.println(arrEntitys.get(atacante).getName()+" ha sacado un "+acierto+" en su tirada, se le suma "+arrEntitys.get(atacante).getPrecission()+" a su tirada de bonificador de precision");
        if (acierto+arrEntitys.get(atacante).getPrecission()>=10+arrEntitys.get(enemigo).getDodge()){
            System.out.println(arrEntitys.get(atacante).getName()+" acierta el ataque");
            int damage = r.nextInt(arrEntitys.get(atacante).getDice())+1;
            damage += arrEntitys.get(atacante).getDamage();
            System.out.println("Daño causado: "+damage);
            int vidaAnterior = arrEntitys.get(enemigo).getHealth();


            entity.setHealth(vidaAnterior - damage);
            arrEntitys.set(enemigo, entity);
            Double valorActualBarra =  barraVida.getProgress();
            if(arrEntitys.get(enemigo).getHealth()<=0){
                enemigoG.setVisible(false);
                barraVida.setVisible(false);
                barraVida.setProgress(0);
            }else{
                barraVida.setProgress((arrEntitys.get(enemigo).getHealth()*valorActualBarra)/vidaAnterior);
            }
        }

        System.out.println("Vida "+arrEntitys.get(enemigo).getName()+" restante: "+arrEntitys.get(enemigo).getHealth());
        return arrEntitys.get(enemigo).getHealth();
    }
}
