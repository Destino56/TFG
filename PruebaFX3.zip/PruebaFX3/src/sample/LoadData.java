package sample;

import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import model.Map;
import model.Sala;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class LoadData {

    public Map cargaInfoMapa(int mapaSeleccionado){

        Map map = new Map();
        BufferedReader bufferedReader;
        boolean salir = false;

        try {
            bufferedReader = new BufferedReader(new FileReader("files/maps.txt"));
            String line="";
            String[] fields = null;

            while ((line=bufferedReader.readLine())!=null && !salir) {
                fields = line.split(";");
                if (Integer.parseInt(fields[2]) == mapaSeleccionado){
                    salir=true;
                }
            }


            map.setNumPiso(Integer.parseInt(fields[0]));
            map.setNombrePiso(fields[1]);
            map.setNumMapa(Integer.parseInt(fields[2]));
            ArrayList<Sala> arrSalas = new ArrayList<>();

            for (int i=0 ; i<(fields.length-2)/4 ; i++){

                Sala sala = new Sala();

                sala.setCordX(Integer.parseInt(fields[(i*4)+3]));
                sala.setCordY(Integer.parseInt(fields[(i*4)+4]));
                sala.setTipoSala(Integer.parseInt(fields[(i*4)+5]));
                sala.setTipoFondo(fields[(i*4)+6]);

                arrSalas.add(sala);
            }

            map.setArrSalas(arrSalas);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return  map;
    }

    public Group cargaCharacter(int cordX, int cordY){

        Group characters;
        ImageView character;

        ArrayList<ImageView> arrCharacter = new ArrayList<>();

        String ruta;
        for (int i=1 ; i<=10 ; i++) {
            ruta = "imgs/shinobi/shinobi_Idle" + i + ".png";
            character = new ImageView(ruta);
            arrCharacter.add(character);
        }

        characters = new Group(arrCharacter.get(0));
        characters.setTranslateX(cordX);
        characters.setTranslateY(cordY);

        Timeline timelineCharacter = new Timeline();
        timelineCharacter.setCycleCount(Timeline.INDEFINITE);

        new Animaciones().animacion(arrCharacter, timelineCharacter, characters, 10);
        timelineCharacter.play();

        return characters;
    }

    public Label cargaLabel(){

        Label dialogo = new Label();
        dialogo.setTranslateX(25);
        dialogo.setTranslateY(525);
        dialogo.setMinWidth(600);
        dialogo.setMaxWidth(600);
        dialogo.setMinHeight(100);
        dialogo.setMaxHeight(100);
        dialogo.setStyle("-fx-background-color: #f7f1f0; -fx-padding: 20px; -fx-font-size: 15px");

        return dialogo;
    }
}
