package sample;

import model.Map;
import model.Sala;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class LoadData {

    public Map cargaInfoMapa(){

        Map map = new Map();
        BufferedReader bufferedReader;

        try {
            bufferedReader = new BufferedReader(new FileReader("files/maps.txt"));
            String line="";
            line=bufferedReader.readLine();
            String[] fields = line.split(";");

            map.setNumPiso(Integer.parseInt(fields[0]));
            map.setNombrePiso(fields[1]);
            map.setNumMapa(Integer.parseInt(fields[2]));
            ArrayList<Sala> arrSalas = new ArrayList<>();

            for (int i=0 ; i<(fields.length-2)/4 ; i++){

                Sala sala = new Sala();

                sala.setCordX(Integer.parseInt(fields[(i*4)+3]));
                sala.setCordY(Integer.parseInt(fields[(i*4)+4]));
                sala.setTipoSala(Integer.parseInt(fields[(i*4)+5]));
                sala.setTipoFondo(fields[(i*4)+6]);

                arrSalas.add(sala);
            }

            map.setArrSalas(arrSalas);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return  map;
    }
}
