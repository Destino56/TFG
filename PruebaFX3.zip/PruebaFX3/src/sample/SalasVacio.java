package sample;

public class SalasVacio {

    public void cargaSalasVacio(){

    }
}
