package sample;

public class SalasTesoro {

    public void cargaSalaTesoro(){

    }
}
