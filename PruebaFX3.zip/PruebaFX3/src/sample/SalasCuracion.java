package sample;

public class SalasCuracion {

    public  void cargaSalasCuracion(){

    }
}
