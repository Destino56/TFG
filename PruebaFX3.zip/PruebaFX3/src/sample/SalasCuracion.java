package sample;

import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Entity;
import model.Map;

import java.util.ArrayList;

public class SalasCuracion {

    private Group fountains;
    private ImageView fountain;

    public  void cargaSalasCuracion(Stage primaryStage, Map map, int indexNuevaSala){

        int cordXActual = map.getArrSalas().get(indexNuevaSala).getCordX();
        int cordYActual = map.getArrSalas().get(indexNuevaSala).getCordY();

        ArrayList<ImageView> arrFountains = new ArrayList<>();


        ImageView background = new ImageView("imgs/background/"+map.getNombrePiso()+map.getArrSalas().get(indexNuevaSala).getTipoFondo()+".png");
        background.setFitHeight(511);
        background.setFitWidth(670);

       LoadData loadData = new LoadData();
       Group characters = loadData.cargaCharacter(0, 175);
       Label dialogo = loadData.cargaLabel();
       dialogo.setText("Has encontrado una fuente con unas aguas cristalinas!");

        String ruta;
        for (int i=1 ; i<=5 ; i++){
            ruta = "imgs/fountain/fuente" + i + ".png";
            fountain = new ImageView(ruta);
            fountain.setFitWidth(275);
            fountain.setFitHeight(350);
            arrFountains.add(fountain);
        }

        fountains = new Group(arrFountains.get(0));
        fountains.setTranslateX(300);
        fountains.setTranslateY(150);

        Timeline timelineF = new Timeline();
        timelineF.setCycleCount(Timeline.INDEFINITE);
        new Animaciones().animacion(arrFountains, timelineF, fountains, 4);
        timelineF.play();

        Button btnBeber = new Button("Beber de la fuente");
        btnBeber.setTranslateX(275);
        btnBeber.setTranslateY(640);
        btnBeber.setOnAction(event -> {
            timelineF.stop();
            fountains.getChildren().setAll(arrFountains.get(4));
            map.getArrSalas().get(indexNuevaSala).setTipoSala(-6);
            dialogo.setText("Has bebido de la fuente y has recuperado 20Hp!");
            ArrayList<Entity> arrEntity = loadData.loadEntitys();
            arrEntity = loadData.loadStatsCharacter(arrEntity);
            if (arrEntity.get(0).getHealth() + 20 >18){
                loadData.updateStatsCharacter(2, String.valueOf(18));
            }else{
                loadData.updateStatsCharacter(2, String.valueOf(arrEntity.get(0).getHealth()+20));
            }

        });

        int numFlechas = Character.getNumericValue(map.getArrSalas().get(indexNuevaSala).getTipoFondo().charAt(0));
        CargaFlechas cargaFlechas = new CargaFlechas();
        Group flechas = cargaFlechas.cargaFlechas(primaryStage, map, cordXActual, cordYActual, numFlechas);

        Group root = new Group(background, characters, fountains, dialogo, flechas, btnBeber);
        Scene scene = new Scene(root);
        scene.getStylesheets().add("styles/styles.css");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
