package sample;

public class SalasAcertijo {

    public void cargaSalasAcertijo(){

    }
}
