package model;

public class Sala {
    private int cordX;
    private int cordY;
    private int tipoSala;
    private String tipoFondo;

    public int getCordX() {
        return cordX;
    }

    public void setCordX(int cordX) {
        this.cordX = cordX;
    }

    public int getCordY() {
        return cordY;
    }

    public void setCordY(int cordY) {
        this.cordY = cordY;
    }

    public int getTipoSala() {
        return tipoSala;
    }

    public void setTipoSala(int tipoSala) {
        this.tipoSala = tipoSala;
    }

    public String getTipoFondo() {
        return tipoFondo;
    }

    public void setTipoFondo(String tipoFondo) {
        this.tipoFondo = tipoFondo;
    }
}
