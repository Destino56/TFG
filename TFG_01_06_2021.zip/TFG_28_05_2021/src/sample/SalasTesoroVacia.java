package sample;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import model.Map;


public class SalasTesoroVacia {

    public void cargaSalaTesoroVacia(Stage primaryStage, Map map, int indexNuevaSala){

        int cordXActual = map.getArrSalas().get(indexNuevaSala).getCordX();
        int cordYActual = map.getArrSalas().get(indexNuevaSala).getCordY();

        ImageView background = new ImageView("imgs/background/"+map.getNombrePiso()+map.getArrSalas().get(indexNuevaSala).getTipoFondo()+".png");
        background.setFitHeight(511);
        background.setFitWidth(670);

        ImageView chest = new ImageView("imgs/chest/chest9.png");
        chest.setFitHeight(115);
        chest.setTranslateX(350);
        chest.setTranslateY(275);

        int numFlechas = Character.getNumericValue(map.getArrSalas().get(indexNuevaSala).getTipoFondo().charAt(0));
        CargaFlechas cargaFlechas = new CargaFlechas();
        Group flechas = cargaFlechas.cargaFlechas(primaryStage, map, cordXActual, cordYActual, numFlechas);

        LoadData loadData = new LoadData();
        Group characters = null;
        if (map.getNombrePiso()=="city/city"){
            characters = loadData.cargaCharacter(0, 230);
        }else{
            characters = loadData.cargaCharacter(0, 175);
        }
        Label dialogo = loadData.cargaLabel();
        dialogo.setText("El cofre ya ha sido saqueado...");

        Group root = new Group(background, characters, dialogo, flechas, chest);
        Scene scene = new Scene(root);
        scene.getStylesheets().add("styles/styles.css");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
