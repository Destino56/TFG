package sample;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Map;

public class SalasVacio {

    public void cargaSalasVacio(Stage primaryStage, Map map, int indexNuevaSala){

        int cordXActual = map.getArrSalas().get(indexNuevaSala).getCordX();
        int cordYActual = map.getArrSalas().get(indexNuevaSala).getCordY();

        ImageView background = new ImageView("imgs/background/"+map.getNombrePiso()+map.getArrSalas().get(indexNuevaSala).getTipoFondo()+".png");
        background.setFitHeight(511);
        background.setFitWidth(670);

        int numFlechas = Character.getNumericValue(map.getArrSalas().get(indexNuevaSala).getTipoFondo().charAt(0));
        CargaFlechas cargaFlechas = new CargaFlechas();
        Group flechas = cargaFlechas.cargaFlechas(primaryStage, map, cordXActual, cordYActual, numFlechas);

        LoadData loadData = new LoadData();
        Group characters = null;
        if (map.getNombrePiso()=="city/city"){
            characters = loadData.cargaCharacter(75, 230);
        }else{
            characters = loadData.cargaCharacter(75, 175);
        }
        Label dialogo = loadData.cargaLabel();

        Group root = new Group(background, characters, dialogo, flechas);
        Scene scene = new Scene(root);
        scene.getStylesheets().add("styles/styles.css");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
