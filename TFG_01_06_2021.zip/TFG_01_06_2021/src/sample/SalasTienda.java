package sample;

import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Map;

import java.util.ArrayList;

public class SalasTienda {

    private Group merchants;
    private ImageView merchant;

    public void cargaSalasTienda(Stage primaryStage, Map map, int indexNuevaSala){

        int cordXActual = map.getArrSalas().get(indexNuevaSala).getCordX();
        int cordYActual = map.getArrSalas().get(indexNuevaSala).getCordY();

        ArrayList<ImageView> arrMerchants = new ArrayList<>();

        ImageView background = new ImageView("imgs/background/"+map.getNombrePiso()+map.getArrSalas().get(indexNuevaSala).getTipoFondo()+".png");
        background.setFitHeight(511);
        background.setFitWidth(670);

        int numFlechas = Character.getNumericValue(map.getArrSalas().get(indexNuevaSala).getTipoFondo().charAt(0));
        CargaFlechas cargaFlechas = new CargaFlechas();
        Group flechas = cargaFlechas.cargaFlechas(primaryStage, map, cordXActual, cordYActual, numFlechas);

        LoadData loadData = new LoadData();
        Group characters = null;
        if (map.getNombrePiso()=="city/city"){
            characters = loadData.cargaCharacter(-40, 230);
        }else{
            characters = loadData.cargaCharacter(-40, 175);
        }
        Label dialogo = loadData.cargaLabel();
        dialogo.setText("Te encuentras con un mercader errante");

        String ruta;
        for (int i=1 ; i<=10 ; i++){
            ruta = "imgs/merchant/merchant" + i + ".png";
            merchant = new ImageView(ruta);
            merchant.setFitWidth(325);
            merchant.setFitHeight(375);
            arrMerchants.add(merchant);
        }

        merchants = new Group(arrMerchants.get(0));
        merchants.setTranslateX(300);
        merchants.setTranslateY(140);

        Timeline timelineP = new Timeline();
        timelineP.setCycleCount(Timeline.INDEFINITE);
        new Animaciones().animacion(arrMerchants, timelineP, merchants, 10);
        timelineP.play();

        Button btnTienda = new Button("Hablar");
        btnTienda.setTranslateX(275);
        btnTienda.setTranslateY(640);
        btnTienda.setOnAction(event -> {
            dialogo.setText("Lo siento chico... Pero ahora mismo no tengo nada que ofrecerte...");
        });

        Group root = new Group(background, characters, dialogo, flechas, merchants, btnTienda);
        Scene scene = new Scene(root);
        scene.getStylesheets().add("styles/styles.css");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
