Lo primero de todo, este juego está en desarrollo, por lo tanto todavía está bastante verde y pueden surgir bugs o problemas.
Ante cualquier bug que localizeis o fallo en el sistema, decirmelo para poder arreglarlo.
-Correo de contacto: alvmarigl56@gmail.com
-Sí me conoces mandame un Whatsapp y ya está

Lo más IMPORTANTE, es necesario tener instalado Java para que el juego funcione, si no lo tienes instalado al intentar
ejecutar el juego te mandará a la página oficial de Java dónde puedes descargarlo.

También estoy abierto a ideas de nuevas mecánicas y contenido, cualquier cosa me decís.

Gracias por jugar :)