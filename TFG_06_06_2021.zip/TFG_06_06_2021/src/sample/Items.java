package sample;

import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import model.Entity;
import model.Item;

import java.util.ArrayList;

public class Items {

    public void activateItemAcertarAtaque(ArrayList<Entity> arrEntitys, int damage, ProgressBar barraVida){
        LoadData loadData = new LoadData();
        ArrayList<Item> arrItems = loadData.loadItems(0);
        for (int i = 0 ; i<arrItems.size() ; i++){
            if (arrItems.get(i).getMomentEffect()==1){
                switch (arrItems.get(i).getId()){

                    case 3:
                        if (arrEntitys.get(0).getHealth() + damage/3 > arrEntitys.get(0).getMaxHealth()){
                            arrEntitys.get(0).setHealth(arrEntitys.get(0).getMaxHealth());
                        }else{
                            arrEntitys.get(0).setHealth(arrEntitys.get(0).getHealth() + damage/3);
                        }
                        Double newValueBarra = (arrEntitys.get(0).getHealth()*1.0)/Double.valueOf(arrEntitys.get(0).getMaxHealth());
                        barraVida.setProgress(newValueBarra);
                        break;
                }
            }
        }
    }

    public void activateItemAciertaEnemigo(ArrayList<Entity> arrEntitys, int damage, ProgressBar vidaJugador, ProgressBar vidaEnemigo, int idEnemigo){
        LoadData loadData = new LoadData();
        ArrayList<Item> arrItems = loadData.loadItems(0);
        for (int i = 0 ; i<arrItems.size() ; i++){
            if (arrItems.get(i).getMomentEffect()==1){
                Double newValueBarra;
                switch (arrItems.get(i).getId()){

                    case 6:
                        damage = damage/2;
                        arrEntitys.get(0).setHealth(arrEntitys.get(0).getHealth()+damage);
                        newValueBarra = Double.valueOf(arrEntitys.get(0).getHealth()*1.0)/(arrEntitys.get(0).getMaxHealth()*1.0);
                        vidaJugador.setProgress(newValueBarra);
                        break;

                    case 7:
                        damage = damage/2;
                        arrEntitys.get(idEnemigo).setHealth(arrEntitys.get(idEnemigo).getHealth()-damage);
                        newValueBarra = Double.valueOf(arrEntitys.get(idEnemigo).getHealth()*1.0)/(arrEntitys.get(idEnemigo).getMaxHealth()*1.0);
                        vidaEnemigo.setProgress(newValueBarra);
                }
            }
        }
    }

    public void activateItemFallarAtaque(Button btnAtacar, Button btnNext){
        LoadData loadData = new LoadData();
        ArrayList<Item> arrItems = loadData.loadItems(0);
        for (int i = 0 ; i<arrItems.size() ; i++){
            if (arrItems.get(i).getMomentEffect()==1){
                switch (arrItems.get(i).getId()){

                    case 5:
                        btnAtacar.setVisible(true);
                        btnNext.setVisible(false);
                        break;
                }
            }
        }
    }

    public void activateItemFinalizarCombate(ArrayList<Entity> arrEntitys){
        LoadData loadData = new LoadData();
        ArrayList<Item> arrItems = loadData.loadItems(0);
        for (int i = 0 ; i<arrItems.size() ; i++){
            if (arrItems.get(i).getMomentEffect()==1){
                switch (arrItems.get(i).getId()){

                    case 4:
                        if ((arrEntitys.get(0).getHealth()+5) > arrEntitys.get(0).getMaxHealth()){
                            arrEntitys.get(0).setHealth(arrEntitys.get(0).getMaxHealth());
                        }else{
                            arrEntitys.get(0).setHealth(arrEntitys.get(0).getHealth()+5);
                        }
                        break;
                }
            }
        }
    }
}
