package sample;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;

public class Animaciones {

    public void animacion(ArrayList<ImageView> arr, Timeline timeline, Group group, int max){
        int tiempoAnimacion;
        for (int i=0 ; i<max ; i++){
            tiempoAnimacion = i + 1;
            int finalI = i;
            timeline.getKeyFrames().add(new KeyFrame(
                    Duration.millis(tiempoAnimacion*100),
                    (ActionEvent event) ->{
                        group.getChildren().setAll(arr.get(finalI));
                    }
            ));
        }
    }

    private Double yOffset;
    private Double xOffset;

    public void ventanaMovible(Stage primaryStage, Group root){
        root.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                xOffset = mouseEvent.getSceneX();
                yOffset = mouseEvent.getSceneY();
            }
        });

        root.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                primaryStage.setX(mouseEvent.getScreenX() - xOffset);
                primaryStage.setY(mouseEvent.getScreenY() - yOffset);
            }
        });
    }
}
