package sample;

import javafx.animation.FadeTransition;
import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.Entity;
import model.Item;
import model.Map;

import java.util.ArrayList;
import java.util.Random;

public class SalasCombate {

    private Group enemies;
    private ImageView enemie;
    private ArrayList<Entity> arrEntitys = new ArrayList<>();
    private Label dialogo;
    private Button btnAtacar, btnNextDialogo;
    private int valueVidaEnemigoAux, contGolpes;
    private Items activateItem = new Items();

    public void cargaSalaCombate(Stage primaryStage, Map map, int indexNuevaSala) {

        LoadData loadData = new LoadData();
        arrEntitys = loadData.loadEntitys();

        int cordXActual = map.getArrSalas().get(indexNuevaSala).getCordX();
        int cordYActual = map.getArrSalas().get(indexNuevaSala).getCordY();

        ArrayList<ImageView> arrEnemies = new ArrayList<>();

        String ruta;
        Random r = new Random();
        int monstruoSeleccionado=0;
        if (map.getNombrePiso() == "forest/fondoBosque"){
            if (map.getArrSalas().get(indexNuevaSala).getTipoSala()==4){
                monstruoSeleccionado = 6;
            }else{
                monstruoSeleccionado = r.nextInt(5) + 1;
            }
        }else if(map.getNombrePiso() == "desert/desierto"){
            if (map.getArrSalas().get(indexNuevaSala).getTipoSala()==4){
                monstruoSeleccionado = 11;
            }else{
                monstruoSeleccionado = r.nextInt(4) + 7;
            }
        }else if(map.getNombrePiso() == "tundra/tundra"){
            if (map.getArrSalas().get(indexNuevaSala).getTipoSala()==4){
                monstruoSeleccionado = 16;
            }else{
                monstruoSeleccionado = r.nextInt(4) + 12;
            }
        }else if (map.getNombrePiso() == "city/city"){
            if (map.getArrSalas().get(indexNuevaSala).getTipoSala()==4){
                monstruoSeleccionado = 21;
            }else{
                monstruoSeleccionado = r.nextInt(4) + 17;
            }
        }else {
            if (map.getArrSalas().get(indexNuevaSala).getTipoSala()==4){
                monstruoSeleccionado = 26;
            }else{
                monstruoSeleccionado = r.nextInt(4) + 22;
            }
        }

        for (int i = 1; i <= arrEntitys.get(monstruoSeleccionado).getNumSprites(); i++) {
            ruta = "imgs/enemies/" + arrEntitys.get(monstruoSeleccionado).getFolder() +
                    "/" + arrEntitys.get(monstruoSeleccionado).getSprite() + i + ".png";
            enemie = new ImageView(ruta);
            enemie.setFitWidth(arrEntitys.get(monstruoSeleccionado).getWidht());
            enemie.setFitHeight(arrEntitys.get(monstruoSeleccionado).getHeight());
            arrEnemies.add(enemie);
        }

        enemies = new Group(arrEnemies.get(0));

        enemies.setTranslateX(arrEntitys.get(monstruoSeleccionado).getPosX());
        enemies.setTranslateY(arrEntitys.get(monstruoSeleccionado).getPosY());

        Timeline timelineCharacter = new Timeline();
        timelineCharacter.setCycleCount(Timeline.INDEFINITE);
        Timeline timelineEnemies = new Timeline();
        timelineEnemies.setCycleCount(Timeline.INDEFINITE);

        new Animaciones().animacion(arrEnemies, timelineEnemies, enemies, arrEnemies.size());
        timelineEnemies.play();

        //Double newVida = Double.valueOf(arrEntitys.get(0).getHealth()/Double.valueOf(arrEntitys.get(0).getMaxHealth()));
        Double newVida = Double.valueOf(arrEntitys.get(0).getHealth()/18.0);
        ProgressBar characterHealth = new ProgressBar(newVida);
        characterHealth.setStyle("-fx-accent: green");
        characterHealth.setTranslateX(arrEntitys.get(0).getPosXVida());
        characterHealth.setTranslateY(arrEntitys.get(0).getPosYVida());

        ProgressBar enemieHealth = new ProgressBar(1);
        enemieHealth.setStyle("-fx-accent: red");
        enemieHealth.setTranslateX(arrEntitys.get(monstruoSeleccionado).getPosXVida());
        enemieHealth.setTranslateY(arrEntitys.get(monstruoSeleccionado).getPosYVida());

        ImageView background = new ImageView("imgs/background/"+map.getNombrePiso()+map.getArrSalas().get(indexNuevaSala).getTipoFondo()+".png");
        background.setFitHeight(611);
        background.setFitWidth(800);

        int numFlechas = Character.getNumericValue(map.getArrSalas().get(indexNuevaSala).getTipoFondo().charAt(0));
        CargaFlechas cargaFlechas = new CargaFlechas();
        Group flechas = cargaFlechas.cargaFlechas(primaryStage, map, cordXActual, cordYActual, numFlechas);

        Group characters = null;
        if (map.getNombrePiso()=="city/city"){
            characters = loadData.cargaCharacter(-40, 320);
        }else if (map.getNombrePiso()=="hell/hell"){
            characters = loadData.cargaCharacter(-40, 340);
        }else{
            characters = loadData.cargaCharacter(-40, 250);
        }
        dialogo = loadData.cargaLabel();

        Group finalCharacters = characters;
        int finalMonstruoSeleccionado = monstruoSeleccionado;

        btnAtacar = new Button("Atacar");
        btnAtacar.setTranslateX(360);
        btnAtacar.setTranslateY(530);
        btnAtacar.setOnAction(event -> {
            btnNextDialogo.setVisible(true);
            btnAtacar.setVisible(false);
            int valueVidaEnemigo = atacar(characterHealth, enemieHealth, 0, arrEntitys.get(finalMonstruoSeleccionado).getId(), enemies);
            valueVidaEnemigoAux = valueVidaEnemigo;
        });

        Button btnMuestraPortal = new Button("Continuar");
        btnNextDialogo = new Button("Continuar");
        btnNextDialogo.setVisible(false);
        btnNextDialogo.setTranslateX(360);
        btnNextDialogo.setTranslateY(530);
        btnNextDialogo.setOnAction(event ->{
            contGolpes = 0;
            if (valueVidaEnemigoAux<=0){
                finalizaCombate(finalMonstruoSeleccionado, map, indexNuevaSala, btnMuestraPortal, flechas, characterHealth, enemieHealth);
            }else{
                int vidaJugador = atacar(enemieHealth, characterHealth, arrEntitys.get(finalMonstruoSeleccionado).getId(), 0, finalCharacters);
                btnNextDialogo.setVisible(false);
                btnAtacar.setVisible(true);
                if (vidaJugador<=0){
                    dialogo.setText("Has sido asesinado a manos del enemigo: "+arrEntitys.get(finalMonstruoSeleccionado).getName());
                    btnAtacar.setVisible(false);
                }else if(arrEntitys.get(finalMonstruoSeleccionado).getHealth()<0){
                    finalizaCombate(finalMonstruoSeleccionado, map, indexNuevaSala, btnMuestraPortal, flechas, characterHealth, enemieHealth);
                }
            }
        });

        btnMuestraPortal.setTranslateX(360);
        btnMuestraPortal.setTranslateY(530);
        btnMuestraPortal.setVisible(false);
        btnMuestraPortal.setOnAction(event -> {
            flechas.setVisible(true);
            map.getArrSalas().get(indexNuevaSala).setTipoSala(-4);
            SalasNextFloor salasNextFloor = new SalasNextFloor();
            salasNextFloor.cargaSalaNextFloor(primaryStage, map, indexNuevaSala);
        });

        Label infoBoss = new Label();
        infoBoss.setStyle("-fx-font-size: 40px;; -fx-font-family: Gabriola; -fx-text-fill: red");
        infoBoss.setTranslateX(125);
        infoBoss.setTranslateY(100);


        flechas.setVisible(false);
        Button btnSalir = loadData.cargaBotonSalir();
        Group buttons = new Group(btnAtacar, btnNextDialogo, btnMuestraPortal, btnSalir);
        Group root = new Group(background, characters, enemies, dialogo, flechas, characterHealth, enemieHealth, infoBoss, buttons);
        Scene scene = new Scene(root);
        scene.getStylesheets().add("styles/styles.css");

        if(map.getArrSalas().get(indexNuevaSala).getTipoSala()==4){
            infoBoss.setText(arrEntitys.get(monstruoSeleccionado).getName());
            FadeTransition fadeTransition2 = new FadeTransition();
            fadeTransition2.setNode(infoBoss);
            fadeTransition2.setFromValue(1);
            fadeTransition2.setToValue(0);
            fadeTransition2.setDuration(Duration.millis(3000));
            fadeTransition2.play();
        }

        new Animaciones().ventanaMovible(primaryStage, root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public int atacar(ProgressBar barraVidaAtacante, ProgressBar barraVidaEnemigo, int atacante, int enemigo, Group enemigoG){
        Entity entity = arrEntitys.get(enemigo);
        Random r = new Random();
        int acierto = r.nextInt(20)+1;
        if (acierto+arrEntitys.get(atacante).getPrecission()>=10+arrEntitys.get(enemigo).getDodge()){
            int damage = r.nextInt(arrEntitys.get(atacante).getDice())+1;
            damage += arrEntitys.get(atacante).getDamage();
            int vidaAnterior = arrEntitys.get(enemigo).getHealth();


            entity.setHealth(vidaAnterior - damage);
            arrEntitys.set(enemigo, entity);
            Double valorActualBarra =  barraVidaEnemigo.getProgress();
            if(arrEntitys.get(enemigo).getHealth()<=0){
                enemigoG.setVisible(false);
                barraVidaEnemigo.setVisible(false);
                barraVidaEnemigo.setProgress(0);
            }else{
                barraVidaEnemigo.setProgress((arrEntitys.get(enemigo).getHealth()*valorActualBarra)/vidaAnterior);
            }
            if (atacante!=0){
                dialogo.setText("El enemigo acierta el ataque!");
                activateItem.activateItemAciertaEnemigo(arrEntitys, damage, barraVidaEnemigo, barraVidaAtacante, atacante);
            }else{
                dialogo.setText("Aciertas el ataque!");
                contGolpes = 0;
                activateItem.activateItemAcertarAtaque(arrEntitys, damage, barraVidaAtacante);
            }

        }else{
            if (atacante!=0){
                dialogo.setText("El enemigo lanza su ataque pero lo esquivas bien");
            }else{
                dialogo.setText("Intentas atacar pero fallas estrepitosamente");
                if (contGolpes == 0){
                    activateItem.activateItemFallarAtaque(btnAtacar, btnNextDialogo);
                }
                contGolpes++;
            }
        }
        return arrEntitys.get(enemigo).getHealth();
    }

    public void finalizaCombate(int finalMonstruoSeleccionado, Map map, int indexNuevaSala, Button btnMuestraPortal, Group flechas, ProgressBar characterHealth, ProgressBar enemieHealth){
        dialogo.setText("Has acabado con el enemigo: "+arrEntitys.get(finalMonstruoSeleccionado).getName());
        btnAtacar.setVisible(false);
        btnNextDialogo.setVisible(false);

        enemies.setVisible(false);
        enemieHealth.setVisible(false);
        enemieHealth.setProgress(0);

        if(map.getArrSalas().get(indexNuevaSala).getTipoSala()==4){
            btnMuestraPortal.setVisible(true);
        }else{
            flechas.setVisible(true);
            map.getArrSalas().get(indexNuevaSala).setTipoSala(1);
        }
        activateItem.activateItemFinalizarCombate(arrEntitys);
        characterHealth.setProgress(Double.valueOf(arrEntitys.get(0).getHealth()/18.0));

        new LoadData().updateStatsCharacter(2, "-"+String.valueOf(arrEntitys.get(0).getHealth()));
    }
}
