package sample;

import javafx.scene.control.ProgressBar;
import model.Entity;
import model.Item;

import java.util.ArrayList;

public class Items {

    public void activateItemTrasAtacar(ArrayList<Entity> arrEntitys, int damage, ProgressBar barraVida){
        LoadData loadData = new LoadData();
        ArrayList<Item> arrItems = loadData.loadItems();
        System.out.println("Llego a la funcion");
        System.out.println(arrItems.size());
        for (int i = 0 ; i<arrItems.size() ; i++){
            System.out.println("Hola "+i);
            switch (arrItems.get(i).getId()){

                case 3:
                    System.out.println("Tienes el item y te has curado");
                    if (arrEntitys.get(0).getHealth() + damage/3 > arrEntitys.get(0).getMaxHealth()){
                        arrEntitys.get(0).setHealth(arrEntitys.get(0).getMaxHealth());
                    }else{
                        arrEntitys.get(0).setHealth(arrEntitys.get(0).getHealth() + damage/3);
                    }
                    Double newValueBarra = (arrEntitys.get(0).getHealth()*1.0)/Double.valueOf(arrEntitys.get(0).getMaxHealth());
                    barraVida.setProgress(newValueBarra);
                    break;
            }
        }
    }
}
