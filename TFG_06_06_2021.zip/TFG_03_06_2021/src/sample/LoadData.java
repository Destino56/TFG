package sample;

import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import model.Entity;
import model.Item;
import model.Map;
import model.Sala;

import java.io.*;
import java.util.ArrayList;

public class LoadData {

    public Map cargaInfoMapa(int mapaSeleccionado, String rutaMapa){

        Map map = new Map();
        BufferedReader bufferedReader;
        boolean salir = false;

        try {
            bufferedReader = new BufferedReader(new FileReader("files/maps.txt"));
            String line="";
            String[] fields = null;

            while ((line=bufferedReader.readLine())!=null && !salir) {
                fields = line.split(";");
                if (Integer.parseInt(fields[2]) == mapaSeleccionado){
                    salir=true;
                }
            }


            map.setNumPiso(Integer.parseInt(fields[0]));
            map.setNombrePiso(rutaMapa);
            map.setNumMapa(Integer.parseInt(fields[2]));
            ArrayList<Sala> arrSalas = new ArrayList<>();

            for (int i=0 ; i<(fields.length-2)/4 ; i++){

                Sala sala = new Sala();

                sala.setCordX(Integer.parseInt(fields[(i*4)+3]));
                sala.setCordY(Integer.parseInt(fields[(i*4)+4]));
                sala.setTipoSala(Integer.parseInt(fields[(i*4)+5]));
                sala.setTipoFondo(fields[(i*4)+6]);

                arrSalas.add(sala);
            }

            map.setArrSalas(arrSalas);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return  map;
    }

    public Group cargaCharacter(int cordX, int cordY){

        Group characters;
        ImageView character;

        ArrayList<ImageView> arrCharacter = new ArrayList<>();

        String ruta;
        for (int i=1 ; i<=10 ; i++) {
            ruta = "imgs/shinobi/shinobi" + i + ".png";
            character = new ImageView(ruta);
            arrCharacter.add(character);
        }

        characters = new Group(arrCharacter.get(0));
        characters.setTranslateX(cordX);
        characters.setTranslateY(cordY);

        Timeline timelineCharacter = new Timeline();
        timelineCharacter.setCycleCount(Timeline.INDEFINITE);

        new Animaciones().animacion(arrCharacter, timelineCharacter, characters, 10);
        timelineCharacter.play();

        return characters;
    }

    public Label cargaLabel(){

        Label dialogo = new Label();
        dialogo.setTranslateX(25);
        dialogo.setTranslateY(625);
        dialogo.setMinWidth(730);
        dialogo.setMaxWidth(730);
        dialogo.setMinHeight(100);
        dialogo.setMaxHeight(100);
        dialogo.setStyle("-fx-background-color: #f7f1f0; -fx-padding: 20px; -fx-font-size: 15px");

        return dialogo;
    }

    public void restartStatsCharacter(){

        BufferedReader bufferedReader;
        BufferedWriter bufferedWriter;

        try {

            bufferedReader = new BufferedReader(new FileReader("files/stats.txt"));
            String line = bufferedReader.readLine();
            bufferedWriter = new BufferedWriter(new FileWriter("files/statsTemporal.txt"));
            bufferedWriter.write(line);
            bufferedWriter.close();

        }catch(FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void restartItemsTemporal(){

        BufferedReader bufferedReader;
        BufferedWriter bufferedWriter;

        try {

            bufferedReader = new BufferedReader(new FileReader("files/items.txt"));
            String line = bufferedReader.readLine();
            bufferedWriter = new BufferedWriter(new FileWriter("files/itemsTemporal.txt"));
            bufferedWriter.write(line);
            bufferedWriter.close();

        }catch(FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Entity> loadEntitys(){

        BufferedReader bufferedReader;
        ArrayList<Entity> arrEntitys = new ArrayList<>();

        try {

            bufferedReader = new BufferedReader(new FileReader("files/stats.txt"));
            String line="";
            while ((line=bufferedReader.readLine())!=null) {
                String[] fields = line.split(";");
                Entity entity = new Entity();
                entity.setId(Integer.parseInt(fields[0]));
                entity.setName(fields[1]);
                entity.setHealth(Integer.parseInt(fields[2]));
                entity.setMaxHealth(Integer.parseInt(fields[3]));
                entity.setDice(Integer.parseInt(fields[4]));
                entity.setDamage(Integer.parseInt(fields[5]));
                entity.setDodge(Integer.parseInt(fields[6]));
                entity.setPrecission(Integer.parseInt(fields[7]));
                entity.setFolder(fields[8]);
                entity.setSprite(fields[9]);
                entity.setWidht(Integer.parseInt(fields[10]));
                entity.setHeight(Integer.parseInt(fields[11]));
                entity.setPosX(Integer.parseInt(fields[12]));
                entity.setPosY(Integer.parseInt(fields[13]));
                entity.setPosXVida(Integer.parseInt(fields[14]));
                entity.setPosYVida(Integer.parseInt(fields[15]));
                entity.setNumSprites(Integer.parseInt(fields[16]));
                arrEntitys.add(entity);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        LoadData loadData = new LoadData();
        arrEntitys = loadData.loadStatsCharacter(arrEntitys);

        System.out.println(arrEntitys.get(0).getName());

        return arrEntitys;
    }

    public ArrayList<Item> loadItems(){

        ArrayList<Item> arrItems = new ArrayList<>();
        BufferedReader bufferedReader;

        try {

            bufferedReader = new BufferedReader(new FileReader("files/itemsTemporal.txt"));
            String line="";
            while ((line=bufferedReader.readLine())!=null) {
                String[] fields = line.split(";");

                if (Integer.parseInt(fields[5]) == 0){
                    Item item = new Item();
                    item.setId(Integer.parseInt(fields[0]));
                    item.setName(fields[1]);
                    item.setDescription(fields[2]);
                    item.setPositionStat(Integer.parseInt(fields[3]));
                    item.setNewValue(Integer.parseInt(fields[4]));
                    item.setMomentEffect(Integer.parseInt(fields[5]));
                    item.setRuta(fields[6]);
                    arrItems.add(item);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return arrItems;
    }

    public ArrayList<Entity> loadStatsCharacter(ArrayList<Entity> arrEntitys){

        BufferedReader bufferedReader;

        try {

            bufferedReader = new BufferedReader(new FileReader("files/statsTemporal.txt"));

            Entity newStatsCharacter = new Entity();
            String line = bufferedReader.readLine();
            String[] fields = line.split(";");

            newStatsCharacter.setId(Integer.parseInt(fields[0]));
            newStatsCharacter.setName(fields[1]);
            newStatsCharacter.setHealth(Integer.parseInt(fields[2]));
            newStatsCharacter.setMaxHealth(Integer.parseInt(fields[3]));
            newStatsCharacter.setDice(Integer.parseInt(fields[4]));
            newStatsCharacter.setDamage(Integer.parseInt(fields[5]));
            newStatsCharacter.setDodge(Integer.parseInt(fields[6]));
            newStatsCharacter.setPrecission(Integer.parseInt(fields[7]));
            newStatsCharacter.setFolder(fields[8]);
            newStatsCharacter.setSprite(fields[9]);
            newStatsCharacter.setWidht(Integer.parseInt(fields[10]));
            newStatsCharacter.setHeight(Integer.parseInt(fields[11]));
            newStatsCharacter.setPosX(Integer.parseInt(fields[12]));
            newStatsCharacter.setPosY(Integer.parseInt(fields[13]));
            newStatsCharacter.setPosXVida(Integer.parseInt(fields[14]));
            newStatsCharacter.setPosYVida(Integer.parseInt(fields[15]));
            newStatsCharacter.setNumSprites(Integer.parseInt(fields[16]));
            arrEntitys.set(0, newStatsCharacter);

            bufferedReader.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return arrEntitys;
    }

    public void updateStatsCharacter(int campoModificar, String newValue){

        BufferedReader bufferedReader;
        BufferedWriter bufferedWriter;

        try {

            bufferedReader = new BufferedReader(new FileReader("files/statsTemporal.txt"));
            String line = bufferedReader.readLine();
            bufferedWriter = new BufferedWriter(new FileWriter("files/statsTemporal.txt"));

            String[] fields = line.split(";");

            if (Integer.parseInt(newValue)<0){
                newValue = String.valueOf(Integer.parseInt(newValue)*-1);
                fields[campoModificar] = newValue;
            }else{
                fields[campoModificar] = String.valueOf(Integer.parseInt(fields[campoModificar]) + Integer.parseInt(newValue));
            }


            for (int i = 0 ; i<fields.length ; i++){
                bufferedWriter.write(fields[i]);
                if(i!=(fields.length-1)){
                    bufferedWriter.write(";");
                }
            }

            bufferedWriter.close();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void updateItemsTemporal(int idItem){

        BufferedReader bufferedReader;
        BufferedWriter bufferedWriter;
        ArrayList <String> arrLineas = new ArrayList<>();
        try {

            bufferedReader = new BufferedReader(new FileReader("files/itemsTemporal.txt"));
            String line;
            Boolean continuar = true;
            while ((line = bufferedReader.readLine()) != null && continuar){
                String[] fields = line.split(";");
                if (Integer.parseInt(fields[0]) == idItem){
                   fields[5]=String.valueOf(1);
                    for (int i = 0 ; i<fields.length ; i++){
                        line += fields[i];
                        if(i!=(fields.length-1)){
                            line +=";";
                        }
                    }
                }

                arrLineas.add(line);
            }

            bufferedWriter = new BufferedWriter(new FileWriter("files/itemsTemporal.txt"));

            for (int i = 0 ; i<arrLineas.size() ; i++){
                bufferedWriter.write(fields[i]);
                if(i!=(fields.length-1)){
                    bufferedWriter.write(";");
                }
            }

            bufferedWriter.close();

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
