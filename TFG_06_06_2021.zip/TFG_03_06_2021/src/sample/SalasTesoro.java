package sample;

import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Item;
import model.Map;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Random;

public class SalasTesoro {

    private Group chests;
    private ImageView chest;
    private ArrayList<Item> arrItems = new ArrayList<>();

    public void cargaSalaTesoro(Stage primaryStage, Map map, int indexNuevaSala){

        LoadData loadData = new LoadData();

        int cordXActual = map.getArrSalas().get(indexNuevaSala).getCordX();
        int cordYActual = map.getArrSalas().get(indexNuevaSala).getCordY();

        ArrayList<ImageView> arrChest = new ArrayList<>();

        ImageView background = new ImageView("imgs/background/"+map.getNombrePiso()+map.getArrSalas().get(indexNuevaSala).getTipoFondo()+".png");
        background.setFitHeight(611);
        background.setFitWidth(800);

        arrItems = loadData.loadItems();

        Group characters = null;
        if (map.getNombrePiso()=="city/city" || map.getNombrePiso()=="hell/hell"){
            characters = loadData.cargaCharacter(-40, 320);
        }else{
            characters = loadData.cargaCharacter(0, 250);
        }
        Label dialogo = loadData.cargaLabel();
        dialogo.setText("Has encontrado un cofre!");

        String ruta;
        for (int i=1 ; i<=9 ; i++){
            ruta = "imgs/chest/chest" + i + ".png";
            chest = new ImageView(ruta);
            chest.setFitHeight(115);
            arrChest.add(chest);
        }
        chests = new Group(arrChest.get(0));
        if(map.getNombrePiso() == "dessert/desierto") {
            chests.setTranslateX(500);
            chests.setTranslateY(350);
        }else if(map.getNombrePiso() == "forest/fondoBosque") {
            chests.setTranslateX(475);
            chests.setTranslateY(350);
        }else if(map.getNombrePiso() == "city/city" || map.getNombrePiso()=="hell/hell") {
            chests.setTranslateX(500);
            chests.setTranslateY(425);
        }else {
            chests.setTranslateX(500);
            chests.setTranslateY(350);
        }

        Timeline timelineC = new Timeline();
        timelineC.setCycleCount(Timeline.INDEFINITE);
        new Animaciones().animacion(arrChest, timelineC, chests, 8);
        timelineC.play();

        Random r = new Random();
        //int itemElegido = r.nextInt(arrItems.size());
        int itemElegido = 3;
        ImageView item = new ImageView("imgs/items/"+arrItems.get(itemElegido).getRuta());
        item.setFitWidth(100);
        item.setFitHeight(100);
        if(map.getNombrePiso() == "dessert/desierto") {
            item.setTranslateX(515);
            item.setTranslateY(275);
        }else if(map.getNombrePiso() == "forest/fondoBosque") {
            item.setTranslateX(490);
            item.setTranslateY(275);
        }else if(map.getNombrePiso() == "city/city" || map.getNombrePiso()=="hell/hell") {
            item.setTranslateX(515);
            item.setTranslateY(350);
        }else{
            item.setTranslateX(515);
            item.setTranslateY(275);
        }
        item.setVisible(false);


        Button btnAbrir = new Button("Abrir cofre");
        btnAbrir.setTranslateX(360);
        btnAbrir.setTranslateY(730);
        btnAbrir.setOnAction(event -> {
            openChest(arrChest, dialogo,  itemElegido, item);
            map.getArrSalas().get(indexNuevaSala).setTipoSala(-3);
            timelineC.stop();
            btnAbrir.setVisible(false);
        });

        int numFlechas = Character.getNumericValue(map.getArrSalas().get(indexNuevaSala).getTipoFondo().charAt(0));
        CargaFlechas cargaFlechas = new CargaFlechas();
        Group flechas = cargaFlechas.cargaFlechas(primaryStage, map, cordXActual, cordYActual, numFlechas);

        Group root = new Group(background, characters, dialogo, flechas, chests, btnAbrir, item);
        Scene scene = new Scene(root);
        scene.getStylesheets().add("styles/styles.css");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void openChest(ArrayList<ImageView> arrChest, Label dialogo, int itemElegido, ImageView item){
        chests.getChildren().setAll(arrChest.get(8));
        item.setVisible(true);
        dialogo.setText("Has abierto el cofre, has encontrado: "+arrItems.get(itemElegido).getName()+"\n-"+
                arrItems.get(itemElegido).getDescription()+"-");
        LoadData loadData = new LoadData();
        loadData.updateStatsCharacter(arrItems.get(itemElegido).getPositionStat(), String.valueOf(arrItems.get(itemElegido).getNewValue()));
        if (arrItems.get(itemElegido).getPositionStat() == 3){
            loadData.updateStatsCharacter(2, String.valueOf(arrItems.get(itemElegido).getNewValue()));
        }
    }
}
