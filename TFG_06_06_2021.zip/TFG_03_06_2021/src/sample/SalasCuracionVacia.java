package sample;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Map;


public class SalasCuracionVacia {

    public  void cargaSalasCuracionVacia(Stage primaryStage, Map map, int indexNuevaSala){

        int cordXActual = map.getArrSalas().get(indexNuevaSala).getCordX();
        int cordYActual = map.getArrSalas().get(indexNuevaSala).getCordY();

        ImageView background = new ImageView("imgs/background/"+map.getNombrePiso()+map.getArrSalas().get(indexNuevaSala).getTipoFondo()+".png");
        background.setFitHeight(611);
        background.setFitWidth(800);

        LoadData loadData = new LoadData();

        Group characters = null;
        if (map.getNombrePiso()=="city/city"){
            characters = loadData.cargaCharacter(0, 320);
        }else if (map.getNombrePiso()=="hell/hell"){
            characters = loadData.cargaCharacter(0, 340);
        }else{
            characters = loadData.cargaCharacter(0, 250);
        }

        Label dialogo = loadData.cargaLabel();
        dialogo.setText("A la fuente no le queda agua...");

        ImageView fountain = new ImageView("imgs/fountain/fuente5.png");
        fountain.setFitWidth(275);
        fountain.setFitHeight(350);
        if(map.getNombrePiso()=="city/city" || map.getNombrePiso()=="hell/hell"){
            fountain.setTranslateX(375);
            fountain.setTranslateY(240);
        }else {
            fountain.setTranslateX(400);
            fountain.setTranslateY(175);
        }


        int numFlechas = Character.getNumericValue(map.getArrSalas().get(indexNuevaSala).getTipoFondo().charAt(0));
        CargaFlechas cargaFlechas = new CargaFlechas();
        Group flechas = cargaFlechas.cargaFlechas(primaryStage, map, cordXActual, cordYActual, numFlechas);

        Group root = new Group(background, characters, fountain, dialogo, flechas);
        Scene scene = new Scene(root);
        scene.getStylesheets().add("styles/styles.css");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
