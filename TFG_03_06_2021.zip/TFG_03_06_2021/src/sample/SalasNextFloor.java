package sample;

import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Map;

import java.util.ArrayList;
import java.util.Random;


public class SalasNextFloor {

    private Group portals;
    private ImageView portal;

    public void cargaSalaNextFloor(Stage primaryStage, Map map, int indexNuevaSala){

        int cordXActual = map.getArrSalas().get(indexNuevaSala).getCordX();
        int cordYActual = map.getArrSalas().get(indexNuevaSala).getCordY();

        ArrayList<ImageView> arrPortals = new ArrayList<>();

        ImageView background = new ImageView("imgs/background/"+map.getNombrePiso()+map.getArrSalas().get(indexNuevaSala).getTipoFondo()+".png");
        background.setFitHeight(611);
        background.setFitWidth(800);

        int numFlechas = Character.getNumericValue(map.getArrSalas().get(indexNuevaSala).getTipoFondo().charAt(0));
        CargaFlechas cargaFlechas = new CargaFlechas();
        Group flechas = cargaFlechas.cargaFlechas(primaryStage, map, cordXActual, cordYActual, numFlechas);

        LoadData loadData = new LoadData();

        Group characters = null;
        if (map.getNombrePiso()=="city/city"){
            characters = loadData.cargaCharacter(0, 320);
        }else if (map.getNombrePiso()=="hell/hell"){
            characters = loadData.cargaCharacter(0, 340);
        }else{
            characters = loadData.cargaCharacter(0, 250);
        }

        Label dialogo = loadData.cargaLabel();
        dialogo.setText("Un portal aparece frente a tí...");

        String ruta;
        for (int i=1 ; i<=9 ; i++){
            ruta = "imgs/portal/portal" + i + ".png";
            portal = new ImageView(ruta);
            portal.setFitWidth(250);
            portal.setFitHeight(325);
            arrPortals.add(portal);
        }

        portals = new Group(arrPortals.get(0));
        if(map.getNombrePiso() == "city/city" || map.getNombrePiso()=="hell/hell") {
            portals.setTranslateX(400);
            portals.setTranslateY(250);
        }else {
            portals.setTranslateX(400);
            portals.setTranslateY(175);
        }

        Timeline timelineP = new Timeline();
        timelineP.setCycleCount(Timeline.INDEFINITE);
        new Animaciones().animacion(arrPortals, timelineP, portals, 9);
        timelineP.play();

        Button btnPortal = new Button("Entrar en el portal");
        btnPortal.setTranslateX(350);
        btnPortal.setTranslateY(730);
        btnPortal.setOnAction(event -> {
            Random r = new Random();
            String nombreMapa="";
            int mapaSeleccionado = r.nextInt((8)) + 9;
            if(map.getNumPiso() == 1){
                int nombreMapaSeleccionado = r.nextInt((2)) + 1;
                if (nombreMapaSeleccionado==1){
                    nombreMapa = "tundra/tundra";
                }else{
                    nombreMapa = "city/city";
                }
            }else{
                mapaSeleccionado = r.nextInt((3)) + 17;
                nombreMapa = "hell/hell";
            }
            Map newMap = loadData.cargaInfoMapa(mapaSeleccionado, nombreMapa);

            SalasInicio salasInicio = new SalasInicio();
            salasInicio.cargaSalaInicio(primaryStage, newMap, 0);
        });

        Group root = new Group(background, characters, dialogo, flechas, portals, btnPortal);
        Scene scene = new Scene(root);
        scene.getStylesheets().add("styles/styles.css");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}
