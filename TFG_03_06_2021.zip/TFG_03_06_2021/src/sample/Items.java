package sample;

public class Items {

    public void activateItem(){

    }
}
